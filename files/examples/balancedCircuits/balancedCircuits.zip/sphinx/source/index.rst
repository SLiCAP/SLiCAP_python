==================
|slicap-h1| report
==================

.. image:: img/colorCode.svg

This is an example of a |slicap| report.

.. |slicap-h1| image:: img/SLiCAP-h1.svg
.. |slicap| image:: img/SLiCAP.svg
