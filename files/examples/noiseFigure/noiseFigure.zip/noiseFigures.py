#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 18 14:29:07 2021

@author: anton
"""

import SLiCAP as sl

sl.initProject('Noise Figures')

from noiseFigureRp import *
from noiseFigureAmp import *
